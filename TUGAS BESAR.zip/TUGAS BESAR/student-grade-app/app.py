from flask import Flask, render_template, request, redirect, url_for, jsonify
import json
import os
from datetime import datetime

app = Flask(__name__)

# Database sederhana menggunakan JSON
DB_FILE = 'students.json'

def get_students():
    if not os.path.exists(DB_FILE):
        return []
    with open(DB_FILE, 'r') as f:
        try:
            return json.load(f)
        except:
            return []

def save_students(students):
    with open(DB_FILE, 'w') as f:
        json.dump(students, f, indent=4)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        students = get_students()
        
        # Generate simple ID based on timestamp
        student_id = f"STD{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        new_student = {
            'id': student_id,
            'name': request.form['name'],
            'npm': request.form['npm'],
            'course': request.form['course'],
            'grade': float(request.form['grade']),
            'semester': request.form['semester'],
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        students.append(new_student)
        save_students(students)
        
        return redirect(url_for('view_grades'))
    
    return render_template('add_student.html')

@app.route('/grades')
def view_grades():
    students = get_students()
    return render_template('view_grades.html', students=students)

@app.route('/api/students', methods=['GET'])
def api_students():
    students = get_students()
    return jsonify(students)

@app.route('/api/students/<student_id>', methods=['DELETE'])
def delete_student(student_id):
    students = get_students()
    students = [s for s in students if s['id'] != student_id]
    save_students(students)
    return jsonify({'success': True})

@app.route('/api/stats', methods=['GET'])
def stats():
    students = get_students()
    
    if not students:
        return jsonify({
            'average': 0,
            'highest': 0,
            'lowest': 0,
            'count': 0
        })
    
    grades = [s['grade'] for s in students]
    
    return jsonify({
        'average': sum(grades) / len(grades),
        'highest': max(grades),
        'lowest': min(grades),
        'count': len(students)
    })

if __name__ == '__main__':
    # Ubah baris ini agar berjalan pada port 8080
    app.run(debug=True, host='0.0.0.0', port=8080)